"use strict";



function showMap() {
   
   // Page objects
    let bikeMap = document.getElementById("bikeMap");
    let bikeDirections = document.getElementById("bikeDirections");
    let startingPoint = document.getElementById("startingPoint");
    let endingPoint = document.getElementById("endingPoint");   
    let bikeFind = new google.maps.DirectionsService()
    let bikeDraw = new google.maps.DirectionsService()
    let Boulder = {lat:40.01753, lng:-105.26496};
    let myMap = new google.maps.Map(bikeMap,{zoom: 12, center: Boulder});
    startingPoint.addEventListener("change", draeRoute);
    endingPoint.addEventListener("change", drawRoute);
    function drawRoute(){
        if (startingPoint.selectedInsex !== 0 && endingPoint.selectedInsex !== 0){
            let bikeRoute = {
                origin: startingPoint.value,
                destination: endingPoint.value,
                travelMode: "Bicycling"
            }
            bikeFind.route(bikeRoute, function(result, status){
                if (status == "OK"){
                    bikeDraw.setDirections(result);
                    bikeDraw.setMap(myMap);
                }else{
                    bikeDirections.textContent = "Directions Unavailable" + status;
                }
            });
        }
    }
}


